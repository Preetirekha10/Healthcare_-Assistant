document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('symptomSearch');
    const symptomItems = document.querySelectorAll('.symptom-item');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const voiceBtn = document.getElementById('voiceBtn');

    // 1. Search Filter Logic
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const term = searchInput.value.toLowerCase();
            symptomItems.forEach(item => {
                const text = item.textContent.toLowerCase();
                item.style.display = text.includes(term) ? 'block' : 'none';
            });
        });
    }

    // 2. Voice Input Feature
    const recognition = window.SpeechRecognition || window.webkitSpeechRecognition ? 
                        new (window.SpeechRecognition || window.webkitSpeechRecognition)() : null;

    if (recognition && voiceBtn) {
        recognition.continuous = false;
        recognition.lang = 'en-US';
        recognition.interimResults = false;

        voiceBtn.onclick = () => {
            try {
                recognition.start();
                voiceBtn.classList.replace('btn-outline-primary', 'btn-danger');
            } catch (e) {
                console.log("Recognition already started or error: ", e);
            }
        };

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript.toLowerCase().replace(/\./g, '');
            searchInput.value = transcript;
            searchInput.dispatchEvent(new Event('input'));
            voiceBtn.classList.replace('btn-danger', 'btn-outline-primary');
        };

        recognition.onerror = () => {
            voiceBtn.classList.replace('btn-danger', 'btn-outline-primary');
            alert("Voice recognition failed. Check microphone permissions.");
        };

        recognition.onend = () => {
            voiceBtn.classList.replace('btn-danger', 'btn-outline-primary');
        };
    } else if (voiceBtn) {
        voiceBtn.style.display = 'none';
    }

    // 3. AI Diagnosis Logic
    if (analyzeBtn) {
        analyzeBtn.onclick = async () => {
            const selected = Array.from(document.querySelectorAll('.sym-check:checked')).map(i => i.value);
            if (selected.length === 0) return alert("Select symptoms!");

            analyzeBtn.disabled = true;
            analyzeBtn.innerText = "Analyzing...";

            try {
                const res = await fetch('/predict', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ symptoms: selected })
                });
                const data = await res.json();

                // Display Result Box
                const resultBox = document.getElementById('resultBox');
                resultBox.style.display = 'block';
                document.getElementById('diseaseName').innerText = data.disease;
                document.getElementById('diseaseDesc').innerText = data.description;
                
                // Set Precautions
                document.getElementById('precautionList').innerHTML = data.precautions.map(p => 
                    `<li class="list-group-item border-0 small"><i class="fas fa-check text-success me-2"></i>${p}</li>`
                ).join('');
                
                // Handle Doctor Information
                const doctor = data.doctor || {};
                const docName = doctor.name || "General Physician";

                // Update/Create Booking Button
                let btn = document.getElementById('bookBtn');
                if(!btn) {
                    btn = document.createElement('button');
                    btn.id = 'bookBtn';
                    btn.className = "btn btn-success w-100 mt-3 py-2 fw-bold rounded-pill";
                    resultBox.appendChild(btn);
                }
                
                btn.innerText = `Book with ${docName}`;

                // FIX: Use URLSearchParams to safely encode names with spaces/special characters
                btn.onclick = () => {
                    const queryParams = new URLSearchParams({
                        disease: data.disease,
                        name: docName,
                        specialist: doctor.specialist || "General",
                        address: doctor.address || "N/A",
                        contact: doctor.contact || "N/A",
                        time: doctor.time || "N/A"
                    }).toString();

                    window.location.href = `/booking?${queryParams}`;
                };
                
            } catch (e) { 
                console.error(e);
                alert("Error connecting to server."); 
            }
            finally { 
                analyzeBtn.disabled = false; 
                analyzeBtn.innerText = "Run Diagnosis"; 
            }
        };
    }
});