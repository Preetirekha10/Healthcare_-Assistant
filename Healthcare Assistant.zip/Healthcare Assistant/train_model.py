import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import pickle

# 1. Load data
df = pd.read_csv('DiseaseAndSymptoms.csv')

# 2. Get unique symptoms
all_symptoms = df.iloc[:, 1:].values.flatten()
unique_symptoms = sorted(list(set([s.strip() for s in all_symptoms if pd.notna(s)])))

# 3. Create Training Matrix
X = pd.DataFrame(0, index=df.index, columns=unique_symptoms)
for i, row in df.iterrows():
    row_symptoms = [s.strip() for s in row[1:] if pd.notna(s)]
    X.loc[i, row_symptoms] = 1

y = df['Disease']

# 4. Train Model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

# 5. Prepare Precautions Lookup
df_pre = pd.read_csv('Disease precaution.csv')
pre_dict = {row['Disease'].strip(): [row[f'Precaution_{j}'] for j in range(1, 5) if pd.notna(row[f'Precaution_{j}'])] 
            for _, row in df_pre.iterrows()}

# 6. Save Assets
pickle.dump(model, open('disease_model.pkl', 'wb'))
pickle.dump(unique_symptoms, open('symptoms_list.pkl', 'wb'))
pickle.dump(pre_dict, open('precautions.pkl', 'wb'))

print("SUCCESS: AI training complete.")