from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import pickle
import numpy as np
import pandas as pd
import os
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import LETTER
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'medical_secure_key'

# --- SQLite Database Configuration ---
# This safely creates a local 'healthcare.db' file inside your root directory.
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///healthcare.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# --- Database Models ---
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False) 
    gender = db.Column(db.String(20))
    age = db.Column(db.Integer)

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    doctor_name = db.Column(db.String(100))
    specialist = db.Column(db.String(100)) 
    visiting_time = db.Column(db.String(50)) 
    disease = db.Column(db.String(100))      
    date = db.Column(db.String(50))
    status = db.Column(db.String(50), default="Confirmed")

class History(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    symptoms = db.Column(db.String(500))
    disease = db.Column(db.String(200))
    medicine = db.Column(db.String(200))
    date = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- 1. Load AI Assets & Doctor Data ---
try:
    model = pickle.load(open('disease_model.pkl', 'rb'))
    symptoms_list = pickle.load(open('symptoms_list.pkl', 'rb'))
    precautions = pickle.load(open('precautions.pkl', 'rb'))
    
    # Load Description with strip to avoid whitespace errors
    desc_df = pd.read_csv('symptom_Description.csv', header=None, names=['Disease', 'Description'])
    descriptions_dict = {str(k).strip(): str(v).strip() for k, v in zip(desc_df['Disease'], desc_df['Description'])}
    
    # Load Doctor Dataset with aggressive cleaning
    doc_df = pd.read_csv('doctors_dataset.csv')
    doc_df.columns = doc_df.columns.str.strip()
    for col in doc_df.columns:
        if doc_df[col].dtype == 'object':
            doc_df[col] = doc_df[col].str.strip()
            
except Exception as e:
    print(f"CRITICAL ERROR loading assets: {e}")

# --- 2. Routes ---

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        gender = request.form.get('gender')
        age = request.form.get('age')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists!', 'danger')
            return redirect(url_for('register'))
            
        hashed_pw = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, password=hashed_pw, gender=gender, age=age)
        
        db.session.add(new_user)
        db.session.commit()
        flash('Account created! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('auth.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid username or password', 'danger')
    return render_template('auth.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/index')
@login_required
def index():
    appointments = Appointment.query.filter_by(user_id=current_user.id).all()
    return render_template('index.html', symptoms=symptoms_list, appointments=appointments)

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    try:
        data = request.get_json()
        selected = data.get('symptoms', [])

        # Prepare input vector
        vector = np.zeros(len(symptoms_list))
        for s in selected:
            if s in symptoms_list:
                vector[symptoms_list.index(s)] = 1

        # Model prediction
        prediction = model.predict([vector])[0].strip()
        print(f"DEBUG: Predicted Disease -> '{prediction}'")

        # Improved matching logic (Case-insensitive)
        match = doc_df[doc_df['Disease'].str.lower() == prediction.lower()]
        
        if not match.empty:
            doctor_row = match.iloc[0]
            doctor_data = {
                'name': str(doctor_row['Name']),
                'specialist': str(doctor_row['Specialist']),
                'address': str(doctor_row['Address']),
                'contact': str(doctor_row['Contact_no']),
                'time': str(doctor_row['Visisting_Time'])
            }
        else:
            # Fallback if no specific doctor is found for the predicted disease
            print(f"DEBUG: No exact match for '{prediction}'. Using fallback.")
            doctor_data = {
                'name': "Dr. Anil Kumar",
                'specialist': "General Physician",
                'address': "CarePlus Health Clinic, Balasore",
                'contact': "9876543210",
                'time': "7 AM - 12 PM"
            }

        # Save to history
        history = History(
            user_id=current_user.id,
            symptoms=", ".join(selected),
            disease=prediction,
            medicine=", ".join(precautions.get(prediction, ["Consult a professional"]))
        )
        db.session.add(history)
        db.session.commit()

        return jsonify({
            'disease': prediction,
            'description': descriptions_dict.get(prediction, "Consult your doctor for a detailed explanation."),
            'precautions': precautions.get(prediction, ["Consult a professional doctor"]),
            'doctor': doctor_data
        })

    except Exception as e:
        print(f"Prediction Error Trace: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/booking')
@login_required
def booking():
    return render_template('booking.html', 
                           disease=request.args.get('disease'),
                           name=request.args.get('name'),
                           specialist=request.args.get('specialist'),
                           address=request.args.get('address'),
                           contact=request.args.get('contact'),
                           time=request.args.get('time'))

@app.route('/book_appointment', methods=['POST'])
@login_required
def book_appointment():
    data = request.json
    try:
        new_booking = Appointment(
            user_id=current_user.id,
            doctor_name=data.get('name'),
            specialist=data.get('specialist'),
            visiting_time=data.get('time'),
            disease=data.get('disease'),
            date=data.get('date'),
            status="Confirmed"
        )
        db.session.add(new_booking)
        db.session.commit()
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/download_appointment/<int:appt_id>')
@login_required
def download_appointment(appt_id):
    appt = Appointment.query.filter_by(id=appt_id, user_id=current_user.id).first_or_404()
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=LETTER)
    
    p.setFont("Helvetica-Bold", 18)
    p.drawString(100, 750, "CareAI Appointment Receipt")
    p.line(100, 740, 500, 740)
    
    p.setFont("Helvetica-Bold", 12)
    p.drawString(100, 710, f"Patient Name: {current_user.username}")
    p.setFont("Helvetica", 12)
    p.drawString(100, 690, f"Doctor Name: {appt.doctor_name}")
    p.drawString(100, 670, f"Specialization: {appt.specialist if appt.specialist else 'N/A'}")
    p.drawString(100, 650, f"Visiting Time: {appt.visiting_time if appt.visiting_time else 'N/A'}")
    p.drawString(100, 630, f"Date: {appt.date}")
    
    p.setFont("Helvetica-Oblique", 10)
    p.drawString(100, 580, "Note: Please arrive 15 minutes prior to your visiting time.")
    p.showPage()
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"Receipt_{appt.id}.pdf", mimetype='application/pdf')

@app.route('/patient_history')
@login_required
def patient_history():
    records = History.query.filter_by(user_id=current_user.id).order_by(History.date.desc()).all()
    return render_template('patient_history.html', records=records, user=current_user)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Generates healthcare.db instantly if it doesn't exist
    app.run(debug=True)